--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2 (Debian 14.2-1.pgdg110+1)
-- Dumped by pg_dump version 14.2 (Debian 14.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "cart-next";
--
-- Name: cart-next; Type: DATABASE; Schema: -; Owner: cart-next
--

CREATE DATABASE "cart-next" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE "cart-next" OWNER TO "cart-next";

\connect -reuse-previous=on "dbname='cart-next'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: pedido; Type: TABLE; Schema: public; Owner: cart-next
--

CREATE TABLE public.pedido (
    id integer NOT NULL,
    credit_card character varying(255) NOT NULL
);


ALTER TABLE public.pedido OWNER TO "cart-next";

--
-- Name: pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: cart-next
--

CREATE SEQUENCE public.pedido_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_id_seq OWNER TO "cart-next";

--
-- Name: pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cart-next
--

ALTER SEQUENCE public.pedido_id_seq OWNED BY public.pedido.id;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: cart-next
--

CREATE TABLE public.produto (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    price numeric NOT NULL
);


ALTER TABLE public.produto OWNER TO "cart-next";

--
-- Name: produto_id_seq; Type: SEQUENCE; Schema: public; Owner: cart-next
--

CREATE SEQUENCE public.produto_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_id_seq OWNER TO "cart-next";

--
-- Name: produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cart-next
--

ALTER SEQUENCE public.produto_id_seq OWNED BY public.produto.id;


--
-- Name: produto_pedido; Type: TABLE; Schema: public; Owner: cart-next
--

CREATE TABLE public.produto_pedido (
    id integer NOT NULL,
    produto_id bigint NOT NULL,
    pedido_id bigint NOT NULL
);


ALTER TABLE public.produto_pedido OWNER TO "cart-next";

--
-- Name: produto_pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: cart-next
--

CREATE SEQUENCE public.produto_pedido_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pedido_id_seq OWNER TO "cart-next";

--
-- Name: produto_pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cart-next
--

ALTER SEQUENCE public.produto_pedido_id_seq OWNED BY public.produto_pedido.id;


--
-- Name: pedido id; Type: DEFAULT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.pedido ALTER COLUMN id SET DEFAULT nextval('public.pedido_id_seq'::regclass);


--
-- Name: produto id; Type: DEFAULT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto ALTER COLUMN id SET DEFAULT nextval('public.produto_id_seq'::regclass);


--
-- Name: produto_pedido id; Type: DEFAULT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto_pedido ALTER COLUMN id SET DEFAULT nextval('public.produto_pedido_id_seq'::regclass);


--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: cart-next
--

COPY public.pedido (id, credit_card) FROM stdin;
\.
COPY public.pedido (id, credit_card) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: cart-next
--

COPY public.produto (id, name, description, price) FROM stdin;
\.
COPY public.produto (id, name, description, price) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: produto_pedido; Type: TABLE DATA; Schema: public; Owner: cart-next
--

COPY public.produto_pedido (id, produto_id, pedido_id) FROM stdin;
\.
COPY public.produto_pedido (id, produto_id, pedido_id) FROM '$$PATH$$/3332.dat';

--
-- Name: pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cart-next
--

SELECT pg_catalog.setval('public.pedido_id_seq', 3, true);


--
-- Name: produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cart-next
--

SELECT pg_catalog.setval('public.produto_id_seq', 3, true);


--
-- Name: produto_pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cart-next
--

SELECT pg_catalog.setval('public.produto_pedido_id_seq', 5, true);


--
-- Name: pedido pedido_pk; Type: CONSTRAINT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pk PRIMARY KEY (id);


--
-- Name: produto_pedido produto_pedido_pk; Type: CONSTRAINT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_pk PRIMARY KEY (id);


--
-- Name: produto produto_pk; Type: CONSTRAINT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pk PRIMARY KEY (id);


--
-- Name: produto_pedido produto_pedido_pedido_fk; Type: FK CONSTRAINT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_pedido_fk FOREIGN KEY (pedido_id) REFERENCES public.pedido(id);


--
-- Name: produto_pedido produto_pedido_produto_fk; Type: FK CONSTRAINT; Schema: public; Owner: cart-next
--

ALTER TABLE ONLY public.produto_pedido
    ADD CONSTRAINT produto_pedido_produto_fk FOREIGN KEY (produto_id) REFERENCES public.produto(id);


--
-- PostgreSQL database dump complete
--

